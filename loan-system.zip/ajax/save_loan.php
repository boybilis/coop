<?php
include '../db.php';

$name = $_POST['name'];
$amount = $_POST['amount'];
$months = $_POST['months'];
$start = $_POST['start_date'];

$rate = 0.02;
$totalInterest = round($amount * $rate * $months, 2);
$totalPayable = round($amount + $totalInterest, 2);

$totalPayments = ceil($months * 2);
$perPayment = $totalPayable / $totalPayments;

$conn->query("INSERT INTO borrowers(name) VALUES('$name')");
$bid = $conn->insert_id;

$conn->query("INSERT INTO loans(borrower_id, amount, months, total_payable, start_date)
VALUES($bid, $amount, $months, $totalPayable, '$start')");

$loan_id = $conn->insert_id;

for($i=1; $i <= $totalPayments; $i++){

    $cycle = $i - 1;
    $monthOffset = floor($cycle / 2);
    $is15 = $cycle % 2 == 0;

    $base = new DateTime($start);
    $base->modify("+$monthOffset month");

    if($is15){
        $base->setDate($base->format('Y'), $base->format('m'), 15);
    } else {
        $base->modify('last day of this month');
    }

    $amountPay = ($i == $totalPayments)
        ? round($totalPayable - ($perPayment * ($totalPayments - 1)), 2)
        : round($perPayment, 2);

    $date = $base->format('Y-m-d');

    $conn->query("INSERT INTO payments(loan_id, payment_no, amount, due_date)
    VALUES($loan_id, $i, $amountPay, '$date')");
}

echo "ok";
