<?php
include '../db.php';
$id = $_GET['id'];
$conn->query("UPDATE payments SET paid=1 WHERE id=$id");
echo "ok";
