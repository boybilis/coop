<?php include 'db.php';
$id = $_GET['id'];
$res = $conn->query("SELECT * FROM payments WHERE loan_id=$id");
?>
<h3>Payment Schedule</h3>
<table border="1">
<tr>
<th>#</th>
<th>Amount</th>
<th>Due Date</th>
<th>Status</th>
<th>Action</th>
</tr>
<?php while($row = $res->fetch_assoc()): ?>
<tr>
<td><?= $row['payment_no'] ?></td>
<td>₱<?= $row['amount'] ?></td>
<td><?= $row['due_date'] ?></td>
<td><?= $row['paid'] ? "Paid" : "Unpaid" ?></td>
<td>
<?php if(!$row['paid']): ?>
<button onclick="markPaid(<?= $row['id'] ?>)">Pay</button>
<?php endif; ?>
</td>
</tr>
<?php endwhile; ?>
</table>

<script>
function markPaid(id){
    fetch('ajax/mark_paid.php?id='+id)
    .then(()=>location.reload());
}
</script>
