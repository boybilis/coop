<?php include 'db.php'; ?>
<h2>Loan Dashboard</h2>
<a href="loan_form.php">➕ Add Loan</a>
<table border="1">
<tr>
<th>Borrower</th>
<th>Amount</th>
<th>Status</th>
<th>Action</th>
</tr>
<?php
$res = $conn->query("
SELECT loans.*, borrowers.name 
FROM loans 
JOIN borrowers ON borrowers.id = loans.borrower_id
");
while($row = $res->fetch_assoc()):
?>
<tr>
<td><?= $row['name'] ?></td>
<td>₱<?= $row['amount'] ?></td>
<td><?= $row['status'] ?></td>
<td><a href="loan_view.php?id=<?= $row['id'] ?>">View</a></td>
</tr>
<?php endwhile; ?>
</table>
