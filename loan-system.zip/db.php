<?php
$conn = new mysqli("localhost", "root", "", "loan_db");
?>