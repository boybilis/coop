<form id="loanForm">
Name: <input type="text" name="name"><br>
Amount: <input type="number" name="amount"><br>
Months: <input type="number" step="0.1" name="months"><br>
Start Date: <input type="date" name="start_date"><br>
<button type="submit">Save Loan</button>
</form>

<script>
document.getElementById("loanForm").onsubmit = function(e){
    e.preventDefault();
    let formData = new FormData(this);
    fetch('ajax/save_loan.php', {
        method: 'POST',
        body: formData
    }).then(res => res.text())
      .then(() => {
          alert("Saved!");
          window.location = "index.php";
      });
}
</script>
